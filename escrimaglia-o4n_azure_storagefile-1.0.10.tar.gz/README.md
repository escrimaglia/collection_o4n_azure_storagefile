# Octupus Collection

Collection o4n_azure_storagefile helps apps to manage Azure FileShare Storage  
By Ed Scrimaglia

## Modules

- o4n_azure_manage_share
- o4n_azure_list_shares
- o4n_azure_manage_directory
- o4n_azure_list_directories
- o4n_azure_upload_files
- o4n_azure_download_files
- o4n_azure_list_files
- o4n_azure_delete_files
